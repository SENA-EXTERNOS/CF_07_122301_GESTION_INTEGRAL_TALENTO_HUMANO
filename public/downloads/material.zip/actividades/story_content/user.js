function ExecuteScript(strId)
{
  switch (strId)
  {
      case "692GShd18Kf":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

