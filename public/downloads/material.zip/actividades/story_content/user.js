function ExecuteScript(strId)
{
  switch (strId)
  {
      case "626SCKQ2EaG":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

